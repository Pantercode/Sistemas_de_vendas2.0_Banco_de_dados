from CadUniClasse import *
from CadUniFuncoes import *
import pandas as pd


cursor = conexaobd()
while True:
    resp = menu(['Cadastrar Usuário', 'Cadastrar Cartão', 'Cadastrar Ônibus', 'Cadastrar Motorista', 'Deletar'])
    if resp == 1: # Opções do Menu(referente ao Usuário)

        dados_nome_user = cad_inserindo_nome()
        dados_sobrenome_user = cad_inserindo_sobrenome()
        dados_bairro_user = cad_inserindo_bairro()
        dados_email_user = cad_inserindo_email()
        dados_nascimento_user = cad_inserindo_dtnascimento()
        resp_user = Usuario(dados_nome_user, dados_sobrenome_user, dados_bairro_user, dados_email_user, dados_nascimento_user)
        print(resp_user.__dict__)
        resp_user.inserir_user(cursor)

#_______________________________________________________________________________________________________________________
    elif resp == 2:   # Opções do Menu(referente ao Cartão)


        dados_proprietario_card = cad_inserindo_idproprietario()
        dados_credito_card = cad_inserindo_quant_creditos()
        dados_tipo_card = cad_tipo_cartao()
        dados_dtemissao_card = cad_dt_emissao()
        resp_card = Cartao(dados_proprietario_card, dados_credito_card, dados_tipo_card, dados_dtemissao_card)
        print(resp_card.__dict__)
        resp_card.inserir_card(cursor)



#_______________________________________________________________________________________________________________________
    elif resp == 3:   # Opções do Menu(referente ao Ônibus)

        dados_linha_bus = numero_linha()
        dados_modelo_bus = modelo_bus()
        dados_fabricacao_bus = ano_fabricacao()
        dados_idmoto_bus = id_moto_buser()
        resp_bus = Onibus(dados_linha_bus, dados_modelo_bus, dados_fabricacao_bus, dados_idmoto_bus)
        print(resp_bus.__dict__)
        resp_bus.inserir_onibus(cursor)



#_______________________________________________________________________________________________________________________
    elif resp == 4:   # Opções do Menu(referente ao Motorista)

        dados_cnh_moto = cnh()
        dados_nome_moto = nome_moto()
        dados_sobrenome_moto = sobrenome_moto()
        dados_nascimento_moto = dtnasc_moto()
        resp_moto = Motorista(dados_cnh_moto, dados_nome_moto, dados_sobrenome_moto, dados_nascimento_moto)
        print(resp_moto.__dict__)
        resp_moto.inserir_motorista(cursor)




    elif resp == 5:
        consultar_User()
        delete = input('Qual id deseja deletar: ')
        deletar_user(cursor, delete)
        consultar_User()
        print('Saindo........')
        break

