import pyodbc
from tabulate import tabulate
import warnings
import pandas as pd



def conexaobd():
    """
    Função que faz a conexão dos dados que estão no sql aliados a dados fornecidos pelo usuário.
    :returns conn.cursor()
    """
    server = 'sql-estudo.database.windows.net'
    driver = '{ODBC Driver 17 for SQL Server}'
    database = 'db-estudos'
    username = 'marcell.oliveira@blueshift.com.br'
    Authentication = 'ActiveDirectoryInteractive'
    port = '1433'
    conn = pyodbc.connect(f'DRIVER={driver};SERVER={server};AUTHENTICATION={Authentication};PORT={port};DATABASE={database};UID={username}')
    cursor = conn.cursor()
    return conn.cursor()

def conexaobdconsulta():
    """
    Função que faz a conexão com conexão .
    :returns conn()
    """
    server = 'sql-estudo.database.windows.net'
    driver = '{ODBC Driver 17 for SQL Server}'
    database = 'db-estudos'
    username = 'marcell.oliveira@blueshift.com.br'
    Authentication = 'ActiveDirectoryInteractive'
    port = '1433'
    conn = pyodbc.connect(f'DRIVER={driver};SERVER={server};AUTHENTICATION={Authentication};PORT={port};DATABASE={database};UID={username}')
    return conn
#_______________________________________________________________________________________________________________________

# Classe Matriz Usuário
class Usuario:
    def __init__(self, nome="", sobrenome="", bairro="", email="", data_nasc=""):
        #self.id_usuario = id_usuario
        self.nome = nome
        self.sobrenome = sobrenome
        self.bairro = bairro
        self.email = email
        self.data_nasc = data_nasc

#________________________________________________________________________________________________________________________


    @property  # GET E SET ID_USUARIO

    def id_usuario(self):
        return self.__id_usuario  # O Set do usario não foi criado pois o sql já faz o set usando como primary key


#_______________________________________________________________________________________________________________________

    @property  # GET E SET NOME
    def nome(self):
       return self.__nome

    @nome.setter
    def nome(self, nome):
        self.__nome= nome
#_______________________________________________________________________________________________________________________

    @property  # GET E SET SOBRENOME
    def sobrenome(self):
       return self.__sobrenome

    @sobrenome.setter
    def sobrenome(self, sobrenome):
        self.__sobrenome = sobrenome

#_______________________________________________________________________________________________________________________

    @property  # GET E SET BAIRRO
    def bairro(self):
        return self.__bairro

    @bairro.setter
    def bairro(self, bairro):
        self.__bairro = bairro

# ______________________________________________________________________________________________________________________

    @property  # GET E SET EMAIL
    def email(self):
        return self.__email

    @email.setter
    def email(self, email):
        self.__email = email

# ______________________________________________________________________________________________________________________

    @property  # GET E SET DATA_NASC
    def data_nasc(self):
        return self.__data_nasc

    @data_nasc.setter
    def data_nasc(self, data_nasc):
            self.__data_nasc = data_nasc

#_______________________________________________________________________________________________________________________

    def inserir_user(self, conn):
        """
         Preenche a tabela com  os dados fornecidos referente ao Usuário que serão inseridos no input.
         :param self:
         :returns: {self.id_usuario}' {self.nome}','{self.sobrenome}', '{self.bairro}',
         '{self.email}', '{self.data_nasc}.
         :param conn
        """
        query = f'''
        INSERT INTO [marcell_oliveira].[usuario_caduni]
        (nome, sobrenome,bairro,email,data_nascimento)
        VALUES( ' {self.nome}','{self.sobrenome}', '{self.bairro}', 
        '{self.email}', '{self.data_nasc}')'''
        exec = conn.execute(query)
        exec.commit()
        return conn.commit


#_______________________________________________________________________________________________________________________


def consultar_User():
    """
    Faz a consulta de tudo que foi adiciona no banco de dados referente ao Usuario.
    :returns: {self.id_usuario}' {self.nome}','{self.sobrenome}', '{self.bairro}',
    '{self.email}', '{self.data_nasc} e df_1.
    """
    conn = conexaobdconsulta()
    query = f""" SELECT * FROM [marcell_oliveira].[usuario_caduni]"""
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', UserWarning)
        df_1 = pd.read_sql(query, conn)
        table = df_1
        headears = ["id_usuario", "nome", "sobrenome", "bairro", "email", "data_nasc"]
        print(tabulate(table, headears, showindex="False", tablefmt="pretty"))
        return df_1



#_______________________________________________________________________________________________________________________


def deletar_user(conn, id_usuario):
    """
     Apaga toda a tabela do id usuario usando como parametro a Primary Key id_usuario.
    :param conn:
    :param id_usuario:
    :return:conn.commit
    """

    query = f'''
            DELETE  FROM [marcell_oliveira].[usuario_caduni] WHERE id_usuario = {id_usuario}'''

    exec = conn.execute(query)
    exec.commit()
    return conn.commit


#_______________________________________________________________________________________________________________________
# Classe Matriz Cartão
class Cartao:
    def __init__(self, id_proprietario="", quant_creditos="", tipo_cartao="", data_emissao=""):
        # self.id_cartao = id_cartao
        self.id_proprietario = id_proprietario
        self.quant_creditos = quant_creditos
        self.tipo_cartao = tipo_cartao
        self.data_emissao = data_emissao

#_______________________________________________________________________________________________________________________

    @property  # GET E SET ID_CARTÃO
    def id_cartao(self):  #O Set do cartão não foi criado pois o sql já faz o set usando como primary key
        return self.__id_cartao


    #_______________________________________________________________________________________________________________________
    @property  # GET E SET ID_PROPRIETARIO
    def id_proprietario(self):
        return self.__id_proprietario

    @id_proprietario.setter
    def id_proprietario(self, id_proprietario):
        self.__id_proprietario = id_proprietario

    #_______________________________________________________________________________________________________________________

    @property  # GET E SET QUANT_CREDITOS
    def quant_creditos(self):
        return self.__quant_creditos


    @quant_creditos.setter
    def quant_creditos(self, quant_creditos):
        self.__quant_creditos = quant_creditos

    #_______________________________________________________________________________________________________________________

    @property  # GET E SET TIPO_CARTÃO
    def tipo_cartao(self):
        return self.__tipo_cartao

    @tipo_cartao.setter
    def tipo_cartao(self, tipo_cartao):
        self.__tipo_cartao = tipo_cartao

    # ______________________________________________________________________________________________________________________
    @property  # GET E SET DATA_EMISSÃO
    def data_emissao(self):
        return self.__data_emissao

    @data_emissao.setter
    def data_emissao(self, data_emissao):
        self.__data_emissao = data_emissao


#_______________________________________________________________________________________________________________________
    def inserir_card(self, conn):
        """
         Preenche com dados do cartão na tabela do banco de dados
        :param self:
        :returns:{self.id_cartao}','{self.id_proprietario}', '{self.quant_creditos}', '{self.tipo_cartao}',
         '{self.data_emissao}, conn.commit.
        :param conn
        """
        query = f'''
        INSERT INTO [marcell_oliveira].[cartao_caduni]
        (id_proprietario,quant_creditos,tipo_cartao,data_emissao)
        VALUES({self.id_proprietario}, {self.quant_creditos}, '{self.tipo_cartao}', '{self.data_emissao}')'''
        exec = conn.execute(query)
        exec.commit()
        return conn.commit





#_______________________________________________________________________________________________________________________
def consultar_card():
    """
    Faz a consulta de tudo que foi adiciona no banco de dados referente ao usuário.
    :returns  df_2

    """
    conn = conexaobdconsulta()
    query = f""" SELECT * FROM [marcell_oliveira].[cartao_caduni]"""
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', UserWarning)
        df_2 = pd.read_sql(query, conn)
        table = df_2
        headears = ["id_cartao", "id_proprietario", "quant_creditos", "tipo_cartao", "data_emissao"]
        print(tabulate(table, headears, showindex="False", tablefmt="pretty"))
        return df_2


#_______________________________________________________________________________________________________________________

def deletar_card(conn, id_cartao):
    """
    Apaga toda a tabela do cartao usando  como parametro a Primary key id_cartao

    :param conn:
    :param id_cartao:
    :return: conn.commit
    """
    query = f'''
           DELETE  FROM [marcell_oliveira].[cartao_caduni] WHERE , id_cartao = {id_cartao}'''

    exec = conn.execute(query)
    exec.commit()
    return conn.commit




#_______________________________________________________________________________________________________________________

#Classe matriz do Onibus
class Onibus:
    def __init__(self, numero_linha="", modelo_onibus="", ano_fabricacao="",  id_motorista=""):
        #self.numero_placa = numero_placa
        self.numero_linha = numero_linha
        self.modelo_onibus = modelo_onibus
        self.ano_fabricacao = ano_fabricacao
        self.id_motorista = id_motorista


#_________________________________________________________________________________________________________________

    @property  # GET E SET NUMERO_PLACA
    def numero_placa(self):  #O Set da placa não foi criado pois o sql já faz o set usando como primary key
        return self.__numero_placa

#_______________________________________________________________________________________________________________________

    @property  # GET E SET NUMERO_LINHA
    def numero_linha(self):
        return self.__numero_linha

    @numero_linha.setter
    def numero_linha(self, numero_linha):
        self.__numero_linha = numero_linha

#_______________________________________________________________________________________________________________________

    @property  # GET E SET MODELO_ONIBUS
    def modelo_onibus(self):
        return self.__modelo_onibus

    @modelo_onibus.setter
    def modelo_onibus(self, modelo_onibus):
        self.__modelo_onibus = modelo_onibus

#_______________________________________________________________________________________________________________________

    @property  # GET E SET ANO_FABRICAÇÃO
    def ano_fabricacao(self):
        return self.__ano_fabricacao

    @ano_fabricacao.setter
    def ano_fabricacao(self, ano_fabricacao):
        self.__ano_fabricacao = ano_fabricacao

#_______________________________________________________________________________________________________________________

    @property  # GET E SET ANO DE ID_MOTORISTA
    def id_motorista(self):
        return self.__id_motorista

    @id_motorista.setter
    def id_motorista(self, id_motorista):
        self.__id_motorista = id_motorista


#_______________________________________________________________________________________________________________________

    def inserir_onibus(self, conn):
        """
        Preenche tabela do banco de dados com dados informados pelo usuario
        :param self:
        :param conn:
        :return: conn.commit
            """
        query = f'''
            INSERT INTO [marcell_oliveira].[onibus_caduni]
            (numero_linha, modelo_onibus, ano_fabricacao, id_motorista)
            VALUES( {self.numero_linha}, '{self.modelo_onibus}', 
        '{self.ano_fabricacao}', '{self.id_motorista}')'''
        exec = conn.execute(query)
        exec.commit()
        return conn.commit

#_______________________________________________________________________________________________________________________

    def deletar_onibus(conn, numero_placa):
        """
        Deleta a tabela onibus usando como parametro a Primary key
        :param conn
        :param numero_placa
        :return conn.commit
        """
        query = f'''
               DELETE  FROM [marcell_oliveira].[onibus_caduni] WHERE , numero_placa = {numero_placa}'''

        exec = conn.execute(query)
        exec.commit()
        return conn.commit

# _______________________________________________________________________________________________________________________

    def consultar_onibus():
        """
        Faz a analise de tudo que foi adicionado na tabela onibus
        :return dt_3
        """
        conn = conexaobdconsulta()
        query = f""" SELECT * FROM [marcell_oliveira].[onibus_caduni]"""
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', UserWarning)
        df_3 = pd.read_sql(query, conn)
        table = df_3
        headears = ["numero_placa", "numero_linha", "modelo_onibus", "ano_fabricacao", "id_motorista"]
        print(tabulate(table, headears, showindex="False", tablefmt="pretty"))


#_______________________________________________________________________________________________________________________
#CLASSE MATRIZ MOTORISTA
class Motorista:
    def __init__(self,numero_cnh, nome, sobrenome, dt_nasc):
       # self.id_motorista = id_motorista
        self.numero_cnh = numero_cnh
        self.nome = nome
        self.sobrenome = sobrenome
        self.dt_nasc = dt_nasc


#_______________________________________________________________________________________________________________________

    @property  # GET E SET ID_MOTORISTA
    def id_motorista(self):  #O Set do id_motorista não foi criado pois o sql já faz o set usando como primary key
        return self.__id_motorista

    #_______________________________________________________________________________________________________________________

    @property  # GET E SET NUMERO_CNH
    def numero_cnh(self):
        return self.__numero_cnh

    @numero_cnh.setter
    def numero_cnh(self, numero_cnh):
        self.__numero_cnh = numero_cnh

    #_______________________________________________________________________________________________________________________

    @property  # GET E SET NOME
    def nome(self):
        return self.__nome

    @nome.setter
    def nome(self, nome):
        self.__nome = nome

    #_______________________________________________________________________________________________________________________

    @property  # GET E SET SOBRENOME
    def sobrenome(self):
        return self.__sobrenome

    @sobrenome.setter
    def sobrenome(self, sobrenome):
        self.__sobrenome = sobrenome

    #_______________________________________________________________________________________________________________________

    @property  # GET E SET DATA_NASCIMENTO
    def data_nasc(self):
        return self.__data_nasc

    @data_nasc.setter
    def data_nasc(self, data_nasc):
        self.__data_nasc = data_nasc

#_______________________________________________________________________________________________________________________

    def inserir_motorista(self, conn):
        """
        Preenche tabela com dados referente ao motorista.
        :param self:
        :returns{self.id_motorista}','{self.numero_cnh}', '{self.nome}',
        '{self.sobrenome}', '{self.dt_nasc} e conn.commit
        :param conn
        """
        query = f'''
          INSERT INTO [marcell_oliveira].[motorista_caduni]
          ( numero_cnh, nome, sobrenome, dt_nasc)
          VALUES( '{self.numero_cnh}', '{self.nome}', '{self.sobrenome}', '{self.dt_nasc}')'''
        exec = conn.execute(query)
        exec.commit()
        return conn.commit



#_______________________________________________________________________________________________________________________
    def consultar_motorista():
        """
        Consulta dentro da tabela Motorista todos os dados estão inseridos referente ao motorista.
         Return  df_4
        """
        conn = conexaobdconsulta()
        query = f""" SELECT * FROM [marcell_oliveira].[motorista_caduni]"""
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', UserWarning)
        df_4 = pd.read_sql(query, conn)
        table = df_4
        headears = ["id_motorista", "numero_cnh", "nome", "sobrenome", "dt_nasc"]
        print(tabulate(table, headears, showindex=False, tablefmt="pretty"))
        return df_4

#_______________________________________________________________________________________________________________________


    def deletar_motorista(conn, id_motorista):
        """
        Deleta a tabela do Motorista usando como parametro Primary Key id_motorista.
      :param conn
      :param id_motorista
      :return conn.commit
        """
        query = f'''
               DELETE  FROM [marcell_oliveira].[motorista_caduni] WHERE , id_motorista = {id_motorista}'''

        exec = conn.execute(query)
        exec.commit()
        return conn.commit


#______________________________________________________________________________________________________________________
# Teste
# cursor = conexaobd()
#user = Usuario()
#
# user.nome = input('Insira seu nome: ')
# user.sobrenome = input('Insira seu sobrenome: ')
# user.email = input('Insira seu email: ')
# user.bairro = input('Nome do bairro: ')
# user.data_nasc = input('Informe sua data de nascimento: ')
# print(user.__dict__)
# input("")
# user.inserir_user(cursor)
#
#_______________________________________________________________________________________________________________________

# card = Cartao()
#
# card.id_proprietario = (input('Insira seu id: '))
# card.quant_creditos = float(input('Insira seu créditos: '))
# card.tipo_cartao = (input('Insira seu cartão[vale transporte/ débito /credito]: '))
# card.data_emissao = input('Informe sua data de emissão do cartão: ')
# print(card.__dict__)
# input("")
# card.inserir_card(cursor)
# # #________________________________________________________________________________________________________________________
#
# bus = Onibus()
#
# bus.numero_placa= input('Insira o numero da placa: ')
# bus.numero_linha= input('Insira o numero linha: ')
# bus.modelo_onibus= input('Insira o modelo do ônibus: ')
# bus.ano_fabricacao = input('Informe o ano de fabricação: ')
# bus.id_motorista = input('Informe id do motorista: ')
# print(bus.__dict__)
# input("")
# bus.inserir_onibus(cursor)
# #_______________________________________________________________________________________________________________________
#
# moto = Motorista()
#
# moto.numero_cnh= input('Informe o numero da cnh: ')
# moto.nome = input('Insira o nome do motorista: ')
# moto.sobrenome = input('Insira o sobrenome do motorista: ')
# moto.dt_nasc = input('Informe a data de nascimento: ')
# print(moto.__dict__)
# input("")
# moto.inserir_motorista(cursor)