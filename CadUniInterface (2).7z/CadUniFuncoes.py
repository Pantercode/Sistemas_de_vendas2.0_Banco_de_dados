from datetime import datetime
import re
from CadUniClasse import *


def conexaobd():
    """
    Função que faz a conexão dos dados que estão no sql aliados a dados fornecidos pelo usuário.
    :returns conn.cursor()
    """
    server = 'sql-estudo.database.windows.net'
    driver = '{ODBC Driver 17 for SQL Server}'
    database = 'db-estudos'
    username = 'marcell.oliveira@blueshift.com.br'
    Authentication = 'ActiveDirectoryInteractive'
    port = '1433'
    conn = pyodbc.connect(
        f'DRIVER={driver};SERVER={server};AUTHENTICATION={Authentication};PORT={port};DATABASE={database};UID={username}')
    cursor = conn.cursor()
    return conn.cursor()


# _______________________________________________________________________________________________________________________
def leiaint(msg):
    while True:
        try:
            n = int(input(msg))
        except (ValueError, TypeError):
            print('\033[32m Erro: Por favor um numero inteiro válido.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro: O usuário preferiu não digitar nada.\033[m')
            return 0
        else:
            return n


# _______________________________________________________________________________________________________________________
def linha(tam=42):  # refere aos tracejados que enfeitam o menu.
    return '-' * tam


# _______________________________________________________________________________________________________________________

def cabecalho(txt):
    print(linha())
    print(txt.center(42))
    print(linha())


# _______________________________________________________________________________________________________________________
def menu(lista):
    cabecalho('MENU PRINCIPAL')
    c = 1
    for item in lista:
        print(f'\033[33m{c}\033[m - \033[34m{item}\033[m')
        c += 1
    print(linha())
    opc = leiaint('\033[32mSua Opção: \033[m')
    return opc

# _______________________________________________________________________________________________________________________

# Base informação do regex https://www.vooo.pro/insights/tutorial-sobre-expressoes-regulares-para-iniciantes-em-python/
# Inserindo dados na tabela usuário e fazendo tratamento dos erros
# re = Expressões regulares Search = procura e match = combinar.
# Regex = expressão regular search e match


#  Inserindo dados na tabela Usuário.
def cad_inserindo_nome():
    while True:
        try:
            dados_nome_user = str(input('Informe o nome do usuário: '))
        except (ValueError, TypeError):
            print('\033[32m Erro!!: Por favor digite um nome usando apenas letras.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro!!: O usuário preferiu não digitar nada.\033[m')
            return 0
        else:
            return dados_nome_user


def cad_inserindo_sobrenome():
    while True:
        try:
            dados_sobrenome_user = str(input('Informe o sobrenome do usuário: '))
        except (ValueError, TypeError):
            print('\033[32m Erro!!: Por favor digite o sobrenome usando apenas letras.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro: O usuário preferiu não digitar nada.\033[m')
            return 0
        else:
            return dados_sobrenome_user


def cad_inserindo_bairro():
    while True:
        try:
            dados_bairro_user = str(input('Informe o bairro: '))
        except (ValueError, TypeError):
            print('\033[32m Erro: Por favor um numero inteiro válido.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro: O usuário preferiu não digitar nada.\033[m')
            return 0
        else:
            return dados_bairro_user


def cad_inserindo_email():
    while True:
        try:
            dados_email_user = input('Insira o email(xxxx@xxx.com ou xxxx@xxx.com): ')
            regex_email_user = '(w+@\w+\.\w+)|(\w+\.+\w+@\w+\.\w+)'
            if (re.search(regex_email_user, dados_email_user)):
                print('Email Válido')

        except (ValueError, TypeError):
            print('\033[32m Erro: Por favor digite uma informação válida.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro: O usuário preferiu não adicionar nada.\033[m')
            return 0
        else:
            return dados_email_user


def cad_inserindo_dtnascimento():
    while True:
        try:
            dados_nascimento_user = str(input('Data de nascimento do usuário (dd/mm/aaaa): '))
            regex_dtnasc_user = "^[0-9]{1,2}\\/[0-9]{1,2}\\/[0-9]{4}$"
            if (re.match(regex_dtnasc_user, dados_nascimento_user)):
                dados_nascimento_user = datetime.strptime(dados_nascimento_user, '%d/%m/%Y').strftime('%Y/%m/%d')
                return dados_nascimento_user
            elif not (re.match(regex_dtnasc_user, dados_nascimento_user)):
                print('\033[32m Erro: Por favor um numero inteiro válido.\033[m')
                continue
        except (ValueError, TypeError):
            print('\033[32m Erro: Por favor um numero inteiro válido.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro: O usuário preferiu não digitar nada.\033[m')
            return 0


# _______________________________________________________________________________________________________________________

# inserindo dados na tabela Cartão.

def id_card():
    while True:
        try:
            dados_id_card = int(input('Informe o id do cartão: '))
        except (ValueError, TypeError):
            print('\033[32m Erro!!: Por favor digite apenas números.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro!!: O usuário preferiu não digitar nada.\033[m')
            return 0
        else:
            return dados_id_card


def cad_inserindo_idproprietario():
    while True:
        try:
            dados_proprietario_card = int(input('Informe o id do propriétario: '))
        except (ValueError, TypeError):
            print('\033[32m Erro!!: Por favor digite apenas números.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro!!: O usuário preferiu não digitar nada.\033[m')
            return 0
        else:
            return dados_proprietario_card


def cad_inserindo_quant_creditos():
    while True:
        try:
            dados_creditos_card = (input('Informe a quantidade de creditos: '))
        except (ValueError, TypeError):
            print('\033[32m Erro: Digite apenas números.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro: O usuário preferiu não digitar nada.\033[m')
            return 0
        else:
            return dados_creditos_card


def cad_tipo_cartao():
    while True:
        try:
            dados_tipo_card = str(input('Informe o tipo do cartão(comum/vale transporte/estudante/idoso): '))
        except (ValueError, TypeError):
            print('\033[32m Erro: Digite apenas letras.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro: O usuário preferiu não digitar nada.\033[m')
            return 0
        else:
            return dados_tipo_card


def cad_dt_emissao():
    while True:
        try:
            dados_dtemissao_card = str(input('Informe a data de emissão do cartão (dd/mm/aaaa): '))
            regex_emissao_card = "^[0-9]{1,2}\\/[0-9]{1,2}\\/[0-9]{4}$"
            if (re.match(regex_emissao_card, dados_dtemissao_card)):
                dados_dtemissao_card = datetime.strptime(dados_dtemissao_card, '%d/%m/%Y').strftime('%Y/%m/%d')
                return dados_dtemissao_card
            elif not (re.match(regex_emissao_card, dados_dtemissao_card)):
                print('\033[32m Erro: Por favor um numero inteiro válido.\033[m')
                continue
        except (ValueError, TypeError):
            print('\033[32m Erro: Por favor um numero inteiro válido.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro: O usuário preferiu não digitar nada.\033[m')
            return 0



# _______________________________________________________________________________________________________________________

# inserindo dados na tabela Ônibus


def numero_linha():
    while True:
        try:
            dados_linha_bus = int(input('Informe o número da linha: '))
        except (ValueError, TypeError):
            print('\033[32m Erro: Digite uma informação válida.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro: O usuário preferiu não digitar nada.\033[m')
            return 0
        else:
            return dados_linha_bus


def modelo_bus():
    while True:
        try:
            dados_modelo_bus = str(input('Informe o modelo do ônibus: '))
        except (ValueError, TypeError):
            print('\033[32m Erro: Digite apenas letras.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro: O usuário preferiu não digitar nada.\033[m')
            return 0
        else:
            return dados_modelo_bus


def ano_fabricacao():

    while True:
        try:
            dados_fabricacao_bus = str(input('Informe o ano de fabricação do ônibus (dd/mm/aaaa): '))
            regex_fabricacao_bus = "^[0-9]{1,2}\\/[0-9]{1,2}\\/[0-9]{4}$"
            if (re.match (regex_fabricacao_bus, dados_fabricacao_bus)):
                dados_fabricacao_bus = datetime.strptime(dados_fabricacao_bus, '%d/%m/%Y').strftime('%Y/%m/%d')
                return dados_fabricacao_bus
            elif not (re.match(regex_fabricacao_bus, dados_fabricacao_bus)):
                print('\033[32m Erro: Por favor digite uma informação válida.\033[m')
                continue
        except (ValueError, TypeError):
            print('\033[32m Erro: Por favor um numero inteiro válido.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro: O usuário preferiu não digitar nada.\033[m')
            return 0


def id_moto_buser():
    while True:
        try:
            dados_idmoto_bus = int(input('Informe o id do motorista: '))
        except (ValueError, TypeError):
            print('\033[32m Erro!!: Por favor digite apenas números.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro!!: O usuário preferiu não digitar nada.\033[m')
            return 0
        else:
            return dados_idmoto_bus


#_______________________________________________________________________________________________________________________
# inserindo dados na tabela  motorista


def cnh():
    while True:
        try:
            dados_cnh_moto = int(input('Informe o numero da cnh do motorista: '))
        except (ValueError, TypeError):
            print('\033[32m Erro!!: Por favor digite uma informação válida.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro!!: O usuário preferiu não digitar nada.\033[m')
            return 0
        else:
            return dados_cnh_moto


def nome_moto():
    while True:
        try:
            dados_nome_moto = str(input('Informe o nome do motorista: '))
        except (ValueError, TypeError):
            print('\033[32m Erro!!: Por favor use apenas letras.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro!!: O usuário preferiu não digitar nada.\033[m')
            return 0
        else:
            return dados_nome_moto


def sobrenome_moto():
    while True:
        try:
            dados_sobrenome_moto = str(input('Informe o sobrenome do motorista: '))
        except (ValueError, TypeError):
            print('\033[32m Erro!!: Por favor use apenas letras.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro!!: O usuário preferiu não digitar nada.\033[m')
            return 0
        else:
            return dados_sobrenome_moto


def dtnasc_moto():
    while True:
        try:
            dados_nascimento_moto = str(input('Data de nascimento do motorista (dd/mm/aaaa): '))
            regex_dtnasc_moto = "^[0-9]{1,2}\\/[0-9]{1,2}\\/[0-9]{4}$"
            if (re.match(regex_dtnasc_moto, dados_nascimento_moto)):
                dados_nascimento_moto = datetime.strptime(dados_nascimento_moto, '%d/%m/%Y').strftime('%Y/%m/%d')
                return dados_nascimento_moto
            elif not (re.match(regex_dtnasc_moto, dados_nascimento_moto)):
                print('\033[32m Erro: Por favor digite uma informação válida.\033[m')
                continue
        except (ValueError, TypeError):
            print('\033[32m Erro: Por favor um numero inteiro válido.\033[m')
            continue
        except KeyboardInterrupt:
            print('\033[32m Erro: O usuário preferiu não digitar nada.\033[m')
            return 0

#_______________________________________________________________________________________________________________________
